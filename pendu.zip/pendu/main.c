#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#include "dico.h"

int gagne(int lettreTrouvee[], long tailleMot);
int rechercheLettre(char lettre, char motSecret[], int lettreTrouvee[]);
char lireCaractere();

int main(int argc, char* argv[])
{
    int quitter=1;
    while (quitter==1)
    {
    printf("****Pendu****** !\n\n");
    printf("*****Menu******");
    printf("\n1-Jouer");
    printf("\n2-Regles du jeu" );
    printf("\n0-Quitter" );
    printf("\n\nChoisissez dans le menu ");
    int choix;
    scanf("%d", &choix);
    if(choix==1)
    {
    int rejouer=1;
    while(rejouer==1)
    {
    char lettre = 0; /* Stocke la lettre inscrite par l'utilisateur */
    char motSecret[100] = {0}; /* Ce sera le mot � trouver*/
    int *lettreTrouvee = NULL; /* Un tableau de bool�ens. Chaque case correspond � une lettre du mot secret. 0 = lettre non trouv�e, 1 = lettre trouv�e*/
    long coupsRestants = 6; /* Compteur de coups restants*/
    long i = 0; /* Une petite variable pour parcourir les tableaux */
    long tailleMot = 0;
    if (!piocherMot(motSecret))
        exit(0);

    tailleMot = strlen(motSecret);

    lettreTrouvee = malloc(tailleMot * sizeof(int)); /* On alloue dynamiquement le tableau lettreTrouvee (dont on ne connaissait pas la taille au d�part)*/
    if (lettreTrouvee == NULL)
        exit(0);

    for (i = 0 ; i < tailleMot ; i++)
        lettreTrouvee[i] = 0;

    /* On continue � jouer tant qu'il reste au moins un coup � jouer ou qu'on
     n'a pas gagn�*/
    while (coupsRestants > 0 && !gagne(lettreTrouvee, tailleMot))
    {
        printf("\n\nIl vous reste %ld coups a jouer", coupsRestants);
        printf("\nQuel est le mot secret ? ");

        /* On affiche le mot secret en masquant les lettres non trouv�es
        Exemple : *I*OU */
        for (i = 0 ; i < tailleMot ; i++)
        {
            if (lettreTrouvee[i]) /* Si on a trouv� la lettre n�i*/
                printf("%c", motSecret[i]);
            else
                printf("*");
        }

        printf("\nProposez une lettre : ");
        lettre = lireCaractere();

        /* Si ce n'�tait PAS la bonne lettre*/
        if (!rechercheLettre(lettre, motSecret, lettreTrouvee))
        {
            coupsRestants--;
        }
    }


    if (gagne(lettreTrouvee, tailleMot))
        printf("\n\nGagne ! Le mot secret etait bien : %s", motSecret);
    else
        printf("\n\nPerdu ! Le mot secret etait : %s", motSecret);

    free(lettreTrouvee); /* On lib�re la m�moire allou�e manuellement (par malloc)*/
    printf("\nRejouer oui:1*****0:non");
    scanf("%d", &rejouer);
    }
        return 0;
    }
    else if(choix==2)
    {
        printf("Principe de jeu");
        printf("Le but du jeu est de deviner en moins de 7 essais un mot que seul lordinateur connait.\n");
        printf("Pour mener � bien votre mission, vous allez proposer une lettre :\n");
        printf("*si la lettre est correcte alors, celle-ci s_affiche a sa place dans le mot a deviner ;\n");
        printf("*si la lettre est incorrecte, alors, votre nombre dessais diminue de 1.  Autrement dit :\n");
        printf("*si la lettre est incorrecte, alors, votre nombre dessais diminue de 1.  Autrement dit :\n");
        printf("*si la lettre est incorrecte, alors, votre nombre dessais diminue de 1.  Autrement dit :\n");
        printf("*si la lettre est incorrecte, alors, votre nombre dessais diminue de 1.  Autrement dit :\n");
        printf("*lorsqu_une lettre est correcte, le nombre dessais reste inchange ;\n");
        printf("*lorsqu_une lettre est incorrecte, le nombre d�essais diminue de 1 ;\n");
        printf("*lorsque tout le mot a ete devine, vous avez gagne ;\n");
        printf("*lorsque le nombre dessais est a zero (0), vous avez perdu.\n");
        printf("Exemple: Supposons que le mot a deviner soit � bonjour �. Vous proposez la lettre � o �, cette derni�re se\n");
        printf("trouve dans le mot, l�ordinateur affiche donc *o**o**. Si vous proposez ensuite la lettre � u �,");
        printf("l�ordinateur affiche : *o**ou*.\n\n");

    }
    else
    {
        printf("Fin du jeu");
    }

        return 0;
    }

}


char lireCaractere()
{
    char caractere = 0;

    caractere = getchar(); /* On lit le premier caract�re*/
    caractere = toupper(caractere); /* On met la lettre en majuscule si elle ne l'est pas d�j�*/

    /* On lit les autres caract�res m�moris�s un � un jusqu'� l'\n*/
    while (getchar() != '\n') ;

    return caractere; /* On retourne le premier caract�re qu'on a lu */
}


int gagne(int lettreTrouvee[], long tailleMot)
{
    long i = 0;
    int joueurGagne = 1;

    for (i = 0 ; i < tailleMot ; i++)
    {
        if (lettreTrouvee[i] == 0)
            joueurGagne = 0;
    }

    return joueurGagne;
}

int rechercheLettre(char lettre, char motSecret[], int lettreTrouvee[])
{
    long i = 0;
    int bonneLettre = 0;

    /* On parcourt motSecret pour v�rifier si la lettre propos�e y est*/
    for (i = 0 ; motSecret[i] != '\0' ; i++)
    {
        if (lettre == motSecret[i]) /* Si la lettre y est*/
        {
            bonneLettre = 1; /* On m�morise que c'�tait une bonne lettre*/
            lettreTrouvee[i] = 1; /* On met � 1 le case du tableau de bool�ens correspondant � la lettre actuelle*/
        }
    }


    return bonneLettre;
}
