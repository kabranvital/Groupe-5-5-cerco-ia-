#include <stdio.h>
#include <stdlib.h>
#include "regles_jeu.h"
#include "jeu.h"

int main()
{
    printf("----Jeu de Pendu------\n" );
    printf("Bienvenue dans le jeu de pendu");
    printf("\n1-Jouer");
    printf("\n2-R�gles du jeu" );
    printf("\n3-Plus grand score" );
    printf("\n0-Quitter" );
    printf("\n\nChoix ");
    int choix;
    scanf("%d", &choix);
    switch(choix)
    {
    case(1):
        mainJeu();
        break;
    case(2):
        regles_jeu();
        break;
    case(3):
        printf("Jouer");
        break;
    case(0):
        printf("Bye");
        break;
    }
    return 0;
}

