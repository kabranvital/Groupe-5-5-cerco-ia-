#ifndef DEF_DICO
#define DEF_DICO

int piocherMot(char *motPioche);
int nombreAleatoire(int nombreMax);

#endif

